import argparse,json,faiss,torch
from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer,AutoModelForCausalLM
from peft import PeftModel
p=argparse.ArgumentParser(); p.add_argument("--question",required=True); p.add_argument("--use_lora",action="store_true"); a=p.parse_args()
embed=SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2"); idx=faiss.read_index("outputs/faiss.index"); docs=json.load(open("outputs/rag_metadata.json"))
q=embed.encode([a.question],normalize_embeddings=True).astype("float32"); scores,ids=idx.search(q,3); chosen=[docs[i] for i in ids[0] if i>=0]
ctx="\n".join(f"[{d['id']}] {d['title']}: {d['text']}" for d in chosen)
prompt=f"Answer using only this context. If it is insufficient, say so. Cite source IDs in brackets.\n{ctx}\nQuestion: {a.question}"
name="Qwen/Qwen2.5-0.5B-Instruct"; tok=AutoTokenizer.from_pretrained(name); model=AutoModelForCausalLM.from_pretrained(name,torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,device_map="auto" if torch.cuda.is_available() else None)
if a.use_lora: model=PeftModel.from_pretrained(model,"outputs/lora_adapter")
x=tok.apply_chat_template([{"role":"user","content":prompt}],tokenize=True,add_generation_prompt=True,return_tensors="pt").to(model.device)
with torch.no_grad(): y=model.generate(x,max_new_tokens=220,do_sample=False,pad_token_id=tok.eos_token_id)
print("Retrieved:",[d["id"] for d in chosen]); print(tok.decode(y[0][x.shape[-1]:],skip_special_tokens=True))
